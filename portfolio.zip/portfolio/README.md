# Portfólio Pessoal - Alex Silva

Portfólio web moderno, responsivo e acessível desenvolvido com HTML, CSS e JavaScript puro.

🔗 **Demo:** (coloque o link do GitHub Pages / Netlify / Vercel aqui)

---

## 🚀 Tecnologias

- HTML5 semântico
- CSS3 (Flexbox, Grid, variáveis CSS, media queries)
- JavaScript (vanilla)
- Font Awesome + Google Fonts

## ✨ Funcionalidades

- Design moderno com tema claro/escuro
- Menu responsivo (hambúrguer no mobile)
- Navegação suave entre seções
- Destaque automático do link ativo no menu
- Formulário de contato com validação
- Botão "Voltar ao topo"
- Cards de projetos e skills
- Totalmente responsivo

## 📁 Estrutura

```
portfolio/
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── script.js
└── README.md
```

## 🛠️ Como rodar localmente

1. Clone o repositório
2. Abra o arquivo `index.html` no navegador  
   **ou** use um servidor local (Live Server no VS Code)

## 📱 Seções

1. **Hero** – Apresentação + botões de CTA
2. **Sobre** – Texto + números de destaque
3. **Skills** – Tecnologias com barras de progresso
4. **Projetos** – Cards com descrição e links
5. **Contato** – Formulário validado + informações

---

## Manutenção – Recuperação Final

> Esta seção será preenchida após a realização das Missões 1, 2 e 3 da Operação Recuperação (UC8).

### 1. Testes realizados
- [ ] Teste de navegação (desktop e mobile)
- [ ] Teste de links e botões
- [ ] Teste de imagens / ícones
- [ ] Teste de responsividade
- [ ] Teste de formulário
- [ ] Teste de acessibilidade básica
- [ ] Teste de tema claro/escuro

### 2. Problemas encontrados
*(preencher após a Missão 1)*

### 3. Correções realizadas
*(preencher após a Missão 1)*

### 4. Melhorias implementadas
*(preencher após a Missão 2)*

### 5. Resultados obtidos
*(preencher após as missões)*

### 6. Evidências de antes e depois
*(adicionar prints)*

---

Feito com 💙 para a recuperação da UC8.
